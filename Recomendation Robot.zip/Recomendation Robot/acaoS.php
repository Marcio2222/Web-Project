<?php
    // Galeria.php
    
    include( 'conexaoDB.php' );
    $fotosAcaos = getFotosAcaos();

        
?>
<!DOCTYPE html>
<head>
<title>QuickPick</title>

    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="icon.gif" />
    <link rel="shortcut icon " type="image/png" href="images/robot.icon.png">
    <script src="javascript.js"></script>
    <div class="bar">  
        <h1 class="title">Quick Pick</h1>
        <a href="Home.php" ><img src="images/offon.png" class="offon"></a>
        </div>

</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar" >
        <div class="sidebar">
            <div class="tab"></div>
            <button class="dropdown-btn">Jogos 
                <i class="fa fa-caret-down"></i>
              </button>
              <div class="dropdown-container">
              <br>
                <a href="rpg.php">RPG</a>
                <br>
                <a href="fps.php">FPS</a>
                <br>
                <a href="fighting.php">Fighting</a>
              </div>
              <div class="tab"></div>
              <button class="dropdown-btn">Filmes 
                <i class="fa fa-caret-down"></i>
              </button>
              <div class="dropdown-container">
              <br>
                <a href="acao.php">Ação</a>
                <br>
                <a href="aventura.php">Aventura</a>
                <br>
                <a href="comedia.php">Comedia</a>
              </div>
              <div class="tab"></div>
            <button class="dropdown-btn">Series 
              <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-container">
            <br>  
              <a href="animacao.php">Animação</a>
              <br>
              <a href="acaoS.php">Ação</a>
              <br>
              <a href="fantasy.php">Fantasy</a>
          
            </div>
          </div>
    </div> 
    <main>
    <section>

<?php
    // Alternative syntax for control structures 
    foreach ($fotosAcaos as $idFotoAcaos  => $urlFotoAcaos  ):
?>

    <div class="foto">
        <img src="<?php echo $urlFotoAcaos ; ?>">
        <h3><?php echo $idFotoAcaos;?></h3>

    </div>

<?php endforeach; ?>

</section>

    </main>

        <div class="speakbox">You Liking The Selection?</div>
        <img src="images/robot.png" class="robot">

   <script>
    /* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
    var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;
    
    for (i = 0; i < dropdown.length; i++) {
      dropdown[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var dropdownContent = this.nextElementSibling;
      if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
      } else {
      dropdownContent.style.display = "block";
      }
      });
    }
    </script>
   
</body>


  