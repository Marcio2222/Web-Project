<?php 
	
  function estabelerConexao()
{
     // Deviam estar num ficheiro de configuração
    $hostname = "localhost";
    $databasename = "fotosbd";
    $username = "root";
    $password = "";
    
    try {
        $conexao = new PDO("mysql:host=$hostname;dbname=$databasename;charset=utf8mb4",
                       $username, $password);
    }
    catch (\PDOException $e) {
        echo $e->getMessage();
    }

    return $conexao;

}

function getFotosRpg() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM rpg');

    $fotosRpg = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosRpg;
}

function getFotosFps() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fps');

    $fotosFps = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosFps;
}

function getFotosFighting() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fighting');

    $fotosFighting = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosFighting;
}

function getFotosFantasy() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fantasy');

    $fotosFantasy = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosFantasy;
}

function getFotosComedia() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM comedia');

    $fotosComedia = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosComedia;
}

function getFotosAventura() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM aventura');

    $fotosAventura = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosAventura;
}

function getFotosAnimacao() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM animacao');

    $fotosAnimacao = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosAnimacao;
}

function getFotosAcaos() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM acaos');

    $fotosAcaos = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosAcaos;
}

function getFotosAcao() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM acao');

    $fotosAcao = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotosAcao;
}
 ?>