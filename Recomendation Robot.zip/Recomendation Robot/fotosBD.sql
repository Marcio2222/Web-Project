CREATE TABLE IF NOT EXISTS `Rpg` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Rpg` (`id`, `url` ) VALUES
('Witcher',	'https://upload.wikimedia.org/wikipedia/en/0/0c/Witcher_3_cover_art.jpg ');
INSERT INTO `Rpg` (`id`, `url` ) VALUES
('Hades', 'https://howlongtobeat.com/games/62941_Hades.jpg' );
INSERT INTO `Rpg` (`id`, `url` ) VALUES
('Skyrim', 'https://upload.wikimedia.org/wikipedia/pt/a/aa/The_Elder_Scrolls_5_Skyrim_capa.png' );
INSERT INTO `Rpg` (`id`, `url` ) VALUES
('Cyberpunk', 'https://s1.gaming-cdn.com/images/products/840/orig/cyberpunk-2077-cover.jpg' );
INSERT INTO `Rpg` (`id`, `url` ) VALUES
('DarkSouls', 'https://www.gamebuyersguide.com/storage/pictures/games/46/box%20art-min.jpg' );            



CREATE TABLE IF NOT EXISTS `Fps` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Fps` (`id`, `url` ) VALUES
('Valorant', 'https://evoww.com/wp-content/uploads/2020/09/682-valorant-cover.png' );
INSERT INTO `Fps` (`id`, `url` ) VALUES
('Apex', 'https://www.mobygames.com/images/covers/l/538006-apex-legends-xbox-one-front-cover.jpg' );
INSERT INTO `Fps` (`id`, `url` ) VALUES
('Titanfall', 'https://s2.gaming-cdn.com/images/products/1273/orig/titanfall-2-cover.jpg' );
INSERT INTO `Fps` (`id`, `url` ) VALUES
('Doom', 'https://i.pinimg.com/originals/d6/52/f8/d652f87f906e6039e4c2844fda1446ad.png' );
INSERT INTO `Fps` (`id`, `url` ) VALUES
('Destiny', 'https://www.mobygames.com/images/covers/l/290440-destiny-playstation-3-front-cover.jpg' );



CREATE TABLE IF NOT EXISTS `Fighting` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Fighting` (`id`, `url` ) VALUES
('Dbfz', 'https://upload.wikimedia.org/wikipedia/en/a/ad/DBFZ_cover_art.jpg');
INSERT INTO `Fighting` (`id`, `url` ) VALUES
('Forhonor', 'https://upload.wikimedia.org/wikipedia/pt/d/d5/For_Honor_cover_art.jpg' );
INSERT INTO `Fighting` (`id`, `url` ) VALUES
('Tekken', 'https://www.gamerview.com.br/wp-content/uploads/2017/06/Tekken-7-Cover-Art.jpg' );
INSERT INTO `Fighting` (`id`, `url` ) VALUES
('Mk11', 'https://upload.wikimedia.org/wikipedia/en/7/7e/Mortal_Kombat_11_cover_art.png' );
INSERT INTO `Fighting` (`id`, `url` ) VALUES
('Storm4', 'https://i.imgur.com/tmsNQDn.jpg' );



CREATE TABLE IF NOT EXISTS `Acao` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Acao` (`id`, `url` ) VALUES
('JohnWick', 'https://images-na.ssl-images-amazon.com/images/I/81F5PF9oHhL._AC_SL1500_.jpg');
INSERT INTO `Acao` (`id`, `url` ) VALUES
('Equalizer', 'https://movieposters2.com/images/1510363-b.jpg' );
INSERT INTO `Acao` (`id`, `url` ) VALUES
('Edge', 'https://i.pinimg.com/originals/6d/d6/ae/6dd6aec1f15519e18036b91aacf84374.jpg' );
INSERT INTO `Acao` (`id`, `url` ) VALUES
('Madmax', 'https://upload.wikimedia.org/wikipedia/en/6/6e/Mad_Max_Fury_Road.jpg' );
INSERT INTO `Acao` (`id`, `url` ) VALUES
('Extraction', 'https://www.what-song.com/images/posters/103370/Extraction-200.jpg' );



CREATE TABLE IF NOT EXISTS `Aventura` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Aventura` (`id`, `url` ) VALUES
('Pirate', 'https://m.media-amazon.com/images/M/MV5BMTYyMTcxNzc5M15BMl5BanBnXkFtZTgwOTg2ODE2MTI@._V1_.jpg' );
INSERT INTO `Aventura` (`id`, `url` ) VALUES
('Fantastic', 'https://m.media-amazon.com/images/M/MV5BMjMxOTM1OTI4MV5BMl5BanBnXkFtZTgwODE5OTYxMDI@._V1_.jpg' );
INSERT INTO `Aventura` (`id`, `url` ) VALUES
('Jurassic', 'https://i.pinimg.com/originals/d2/33/4e/d2334e613ad0ddacf5354b3965c5a8ff.jpg' );
INSERT INTO `Aventura` (`id`, `url` ) VALUES
('Revenant', 'https://images-na.ssl-images-amazon.com/images/I/712nPTA1EPL._AC_SL1500_.jpg' );
INSERT INTO `Aventura` (`id`, `url` ) VALUES
('Interstellar', 'https://images-na.ssl-images-amazon.com/images/I/81kz06oSUeL._AC_SL1500_.jpg' );



CREATE TABLE IF NOT EXISTS `Comedia` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Comedia` (`id`, `url` ) VALUES
('Ted'	,	'https://i.pinimg.com/originals/bf/72/e1/bf72e1e65c06a437e26c55060008d0f9.jpg');
INSERT INTO `Comedia` (`id`, `url` ) VALUES
('Hangover', 'https://www.coverwhiz.com/uploads/movies/The-Hangover-Part-1.jpg' );
INSERT INTO `Comedia` (`id`, `url` ) VALUES
('Kickass', 'https://cdn.waterstones.com/bookjackets/large/9781/8485/9781848565357.jpg' );
INSERT INTO `Comedia` (`id`, `url` ) VALUES
('Jumanji', 'https://static.raru.co.za/cover/2018/03/02/6468447-l.jpg?v=1519991954' );
INSERT INTO `Comedia` (`id`, `url` ) VALUES
('West', 'https://upload.wikimedia.org/wikipedia/en/2/22/A_Million_Ways_to_Die_in_the_West_poster.jpg' );



CREATE TABLE IF NOT EXISTS `Animacao` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Animacao` (`id`, `url` ) VALUES
('Naruto', 'https://cdn.myanimelist.net/images/anime/13/17405.jpg' );
INSERT INTO `Animacao` (`id`, `url` ) VALUES
('Onepiece', 'https://preview.redd.it/r33rwz63f5j51.jpg?auto=webp&s=502c03b2fabec7d3f2dc678bc3700905bbe292ae' );
INSERT INTO `Animacao` (`id`, `url` ) VALUES
('Attackontitan', 'https://tibs2.threeifbyspace.net/wp-content/uploads/2020/05/visual.jpg' );
INSERT INTO `Animacao` (`id`, `url` ) VALUES
('Rezero', 'https://pm1.narvii.com/6359/8cec8079ed06f64203589c9b350adccac9e192af_00.jpg' );
INSERT INTO `Animacao` (`id`, `url` ) VALUES
('Jujutsukaisen', 'https://cdn.myanimelist.net/images/anime/1171/109222l.jpg' );



CREATE TABLE IF NOT EXISTS `AcaoS` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `AcaoS` (`id`, `url` ) VALUES
('Shooter', 'https://occ-0-2568-2567.1.nflxso.net/art/82e69/aa5cc83f8ca25b66d4cc57c35f0a076c49782e69.jpg' );
INSERT INTO `AcaoS` (`id`, `url` ) VALUES
('Arrow', 'https://i.pinimg.com/originals/80/b6/a2/80b6a2c4d26a39309b0b53362abfc13f.jpg' );
INSERT INTO `AcaoS` (`id`, `url` ) VALUES
('Daredevil', 'https://i.pinimg.com/originals/60/63/14/60631495ec9d2f26ea010af94ce21588.jpg' );
INSERT INTO `AcaoS` (`id`, `url` ) VALUES
('Gotham', 'https://images-na.ssl-images-amazon.com/images/I/81yQcA5Xv%2BL._SL1500_.jpg' );
INSERT INTO `AcaoS` (`id`, `url` ) VALUES
('Vikings', 'https://i.pinimg.com/originals/d8/e9/48/d8e9486cc52394eb7519f7c65a456202.jpg' );



CREATE TABLE IF NOT EXISTS `Fantasy` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `Fantasy` (`id`, `url` ) VALUES
('Witcher', 'https://br.web.img3.acsta.net/pictures/19/11/29/17/57/5161763.jpg' );
INSERT INTO `Fantasy` (`id`, `url` ) VALUES
('Got', 'https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/5ce657c1240000f3107f21e5-1558701153.jpg' );
INSERT INTO `Fantasy` (`id`, `url` ) VALUES
('Stranger', 'https://images-na.ssl-images-amazon.com/images/I/61C4T5HmR9L.jpg' );
INSERT INTO `Fantasy` (`id`, `url` ) VALUES
('Umbrella', 'https://br.web.img3.acsta.net/pictures/18/12/10/14/01/0178829.jpg' );
INSERT INTO `Fantasy` (`id`, `url` ) VALUES
('Jessicajones', 'https://images-na.ssl-images-amazon.com/images/I/91xT8BC94dL._SL1495_.jpg' );