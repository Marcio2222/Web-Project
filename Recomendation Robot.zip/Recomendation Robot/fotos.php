<?php 


    $Rpg = array ( 
          	'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',);
            
     $Fps = array ( 
            'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',);     

      $Fighting = array ( 
            'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',);

      $Acao = array ( 
            'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',);

      $Aventura = array ( 
            'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',);

      $Comedia = array ( 
            'Ted'	=>	'https://i.pinimg.com/originals/bf/72/e1/bf72e1e65c06a437e26c55060008d0f9.jpg',
            'KickAss'	=>	'https://cdn.waterstones.com/bookjackets/large/9781/8485/9781848565357.jpg',
            'West'	=>	'https://mk0movieguide99l7786.kinstacdn.com/wp-content/uploads/2014/05/a-million-ways-to-die-in-the-west-1.25683.jpg',
            'Jumanji'	=>	'https://static.raru.co.za/cover/2018/03/02/6468447-l.jpg?v=1519991954',
            'Hangover'	=>	'https://www.coverwhiz.com/uploads/movies/The-Hangover-Part-1.jpg',);

      $Animacao = array ( 
            'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',);

      $AcaoS = array ( 
            'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',);

      $Fantasia = array ( 
            'Witcher'	=>	'https://store-images.s-microsoft.com/image/apps.28990.69531514236615003.8f0d03d6-6311-4c21-a151-834503c2901a.d629260e-2bc4-4588-950c-f278cbc22a64?mode=scale&q=90&h=300&w=200',
            'Hades'	=>	'https://images.ctfassets.net/5owu3y35gz1g/2C6PuqIHTfKw9M5PqhnWpp/e01e76c6dd1a591b5765a3dbf9f1f207/Hades_PackArt_2.jpg?w=225&h=310&q=100',
            'Skyrim'	=>	'https://upload.wikimedia.org/wikipedia/en/1/15/The_Elder_Scrolls_V_Skyrim_cover.png',
            'CyberPunk'	=>	'https://static-01.daraz.pk/p/b1e779a814b3609df8c5e2d28c58064c.jpg',
            'DarkSouls'	=>	'https://upload.wikimedia.org/wikipedia/pt/e/e9/Dark_Souls_3_capa.png',
           );


 ?>